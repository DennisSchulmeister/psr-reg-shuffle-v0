~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                         PSR Registration Shuffler 0.3

            (A program for organizing your registration bank files)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

TALE OF CONTENTS
----------------

  1. Purpose of the program
  2. Feature overview
  3. Known captchas
  4. Further information
  5. Copyright


1. PURPOSE OF THE PROGRAM
-------------------------

If you're using your PSR keyboard for live gigs you're most probably employing
its registration banks for storing each song's panel settings. After some time
you might grow quite a large set of registration banks this way. While creating
those is quite straight-forward organization is quite time consuming. Especially
if you have your banks organized according to your set list.

In most cases a song's settings don't change (much) between gigs. But the set
list might change. And than you're spending quite some time with assembling new
registration banks out of your existing banks. What makes the process so time
consuming is the fact that you always have to store your new bank to disk in
order to load another one which holds the settings for the next song. Than
you need to load the new bank again for storing the song in it. And so on.

The PSR Registration Shuffler is meant to set an abrupt end to this. You will
still need to create your registrations on the keyboard. And you need to apply
changes to them on the keyboard, too. But when you're preparing for an
upcoming gig and need to assemble new bank files out of pre-existing
registrations only, you can do so within the comfort of your computer at a
speed unmatched by the keyboard.


2. FEATURE OVERVIEW
-------------------

As of version 0.3 the PSR Registration Shuffler can read and write registration
banks of the following keyboard models:

 » Yamaha PSR-2000
 » Yamaha PSR-3000
 » Yamaha PSR-S700
 » Yamaha PSR-S900
 » Yamaha Tyros
 » Yamaha Tyros 2
 » Yamaha Tyros 3

Whereas the following operations can be performed:

 » Read in registration banks and extract its content
 » Assemble new registration banks
 » Rename registrations during all stages of operation
 » Create registration banks in batch mode having all registrations either
   sorted by name (ascending as well as descending) or in random order
 » Quick edit registration banks (registration names and ordering)
 » Export and Printing of set lists

Since the program has been written using python and GTK+ only, it should run
on virtually any modern operating system. The following systems have already
been tested:

 » GNU/Linux
 » Microsoft Windows


3. KNOWN CAPTCHAS
-----------------

There could be support for many more keyboard models. Although many keyboards
of a line share a very similar file format it might be that support for your
specific model is missing, yet. Unfortunately many file formats remain
unexplored because there has simply no one stepped forward yet and provided
sufficient test data. So if you want your certain instrument to be supported
please come in touch with me.

Although the list of available registration can be sorted alphabetically it
might happen the in batch mode registrations get stored in a slightly different
order. The reason for this lies on the behaviour of the displayed list. It
sorts CAPITALIZED words in front of mixed-case or lower-cased words disregarding
the alphabet. Unfortunately this can't be influenced. In batch mode however
a manual sort algorithm gets used which strictly sorts by alphabet as if all
words were capitalized.

The MS Windows version doesn't respect the user specific GTK-setting, whether
images should be shown on buttons or not. This is because the default behaviour
of GTK's Windows version is to hide images and the average user wouldn't want
to edit the gtkrc files.

At the moment this program is maintained by just one person (me). However as
it is put under a free-software licence it could definitely use more hands
working on it. This does not necessarily involve programming. There are many
ways to contribute. If you feel up to the task please get in touch with me.


4. FURTHER INFORMATION
----------------------

More information about program usage can be found in its man page. If you're
on a Unix based operating system type

$ man psrregshuffle

to see it. On other systems there's most probably no manual viewer. Due to
this fact the manual can also be seen on the official website of the program.

For an online version and more information visit: http://www.psrregshuffle.de

As of October 2008 an extensive user-guide is in the making but not available
yet. Future program versions will contain a copy as well as the above mentioned
website.


5. COPYRIGHT
------------

The PSR Registration Shuffler is (C) 2008 Dennis Schulmeister. It is licenced
under the terms of the GNU GPL 3 or (at your option) any later version.

(C) 2008 Dennis Schulmeister  <dennis -at- ncc-1701a.homelinux.net>
http://www.psrregshuffle.de
