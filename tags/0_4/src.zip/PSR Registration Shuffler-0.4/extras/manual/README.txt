At the moment there is no full-fledged manual yet as its creation is scheduled
after release of program version 0.4. Please see http://www.psrregshuffle.de
for regular updates.
